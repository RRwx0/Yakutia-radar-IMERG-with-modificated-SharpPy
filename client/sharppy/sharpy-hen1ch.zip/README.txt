SHARPpy — модификация hen1ch
=========================================

Автор модификации и оболочки: hen1ch, 2026

Состав:
  wx_launcher.py      — оболочка: источники, кеш, карта, просмотр
  sharppy_core.py     — ядро расчётов и Skew-T
  sharppy_layout.py   — компоновка окна SHARPpy и врезки
  stations_lookup.py  — поиск станций, ICAO, координаты
  i18n.py             — русский и английский интерфейс

Запуск:
  pip install requests
  python wx_launcher.py

Для расчётов и графиков нужен установленный SHARPpy:
  conda install -c conda-forge sharppy
